function enviar(){
  //console.log(document.getElementById('categoria').value)
  categ = document.getElementById('categoria').value
  plaz = document.getElementById('plazo').value
  gasto = document.getElementById('montototal').value
  // Crear una colección de textos usando un array
  gpt = ["Veo que simulaste el uso de un servicio en un plazo de "+plaz+" meses y un total a pagar de "+(plaz*gasto)+" pesos. La elección de un servicio de Internet depende de tu ubicación, necesidades y presupuesto. Investiga proveedores locales, compara planes y verifica la velocidad y confiabilidad del servicio.", "Veo que simulaste un crédito en un plazo de "+plaz+" meses con una tasa de interés del 9%, el crédito es de "+gasto+" pesos. Mensualmente pagarías "+((gasto/plaz)+(9/100)*(gasto/plaz))+" pesos con la tasa de interés ya incluida y en "+plaz+" meses pagarías "+plaz*((gasto/plaz)+(9/100)*(gasto/plaz))+" pesos.", "Crea un Presupuesto: Un presupuesto es una herramienta esencial para administrar tus finanzas de manera efectiva. Toma el tiempo para establecer un presupuesto mensual que incluya tus ingresos y gastos. Esto te ayudará a controlar tus gastos, identificar áreas de ahorro y asegurarte de que estás viviendo dentro de tus posibilidades.", "Ahorra e Invierte Regularmente: No solo ahorres dinero, sino también inviértelo. El ahorro te proporciona una red de seguridad en caso de emergencias, mientras que la inversión te permite hacer que tu dinero crezca con el tiempo. Considera abrir una cuenta de ahorros o invertir en opciones como fondos indexados o acciones, dependiendo de tu tolerancia al riesgo y tus metas financieras a largo plazo."];


  console.log(gasto/plaz)

  document.getElementById('grafica').innerHTML='<canvas id="miGrafico"></canvas> <br>'


  // Obtén una referencia al elemento canvas
  var ctx = document.getElementById('miGrafico').getContext('2d');

  // Define los datos de gasto en pesos y meses
  var gastoData = [gasto/plaz, 1200, 800, 1500, 2000,gasto/plaz, 1200, 3000, 500, 700,gasto/plaz, 1210]; // Reemplaza con tus datos
  var mesesData = ['Octubre', 'Noviembre', 'Diciembre', 'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio','Agosto','Septiembre']; // Reemplaza con tus datos

  // Configura el gráfico de líneas
  var myChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: mesesData, // Etiquetas en el eje X (meses)
      datasets: [{
        label: categ,
        data: gastoData, // Datos de gasto en el eje Y
        borderColor: 'blue', // Color de la línea
        borderWidth: 2 // Ancho de la línea
      }]
    },
    options: {
      responsive: true, // Hacer el gráfico responsive
      scales: {
        y: {
          beginAtZero: true // Empezar en 0 en el eje Y
        }
      }
    }
  });


  if(categ=='servicios'){
    document.getElementById('generatorIA').innerHTML='<p id="textIA">'+gpt[0]+'</p>'
  }else if(categ=='prestamos'){
    document.getElementById('generatorIA').innerHTML='<p id="textIA">'+gpt[1]+'</p>'
  }else{
const numeroAleatorio = Math.floor(Math.random() * 2); // Esto generará 0 o 1
// Elegir entre la posición 2 o 3 según el número aleatorio
if (numeroAleatorio === 0) {
  document.getElementById('generatorIA').innerHTML='<p id="textIA">'+gpt[2]+'</p>'
} else {
  document.getElementById('generatorIA').innerHTML='<p id="textIA">'+gpt[3]+'</p>'
}
  }


}

//api vertx